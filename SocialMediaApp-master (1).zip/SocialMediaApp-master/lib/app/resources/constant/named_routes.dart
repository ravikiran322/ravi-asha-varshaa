class NamedRoutes {
  static const homeScreen = '/home-screen';
  static const profileScreen = '/ticket-screen';
}
